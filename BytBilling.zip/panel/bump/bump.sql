-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Gazdă: 127.0.0.1
-- Timp de generare: ian. 13, 2021 la 01:18 PM
-- Versiune server: 10.4.14-MariaDB
-- Versiune PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Bază de date: `billing`
--

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `accounts`
--

CREATE TABLE `accounts` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL DEFAULT 'none',
  `last_name` varchar(255) NOT NULL DEFAULT 'none',
  `phone` varchar(255) NOT NULL DEFAULT '+0000000',
  `email` varchar(255) NOT NULL DEFAULT 'none',
  `password` varchar(255) NOT NULL DEFAULT 'none',
  `country` varchar(255) NOT NULL DEFAULT 'none',
  `city` varchar(255) NOT NULL DEFAULT 'none',
  `postal_code` varchar(255) NOT NULL DEFAULT 'none',
  `age` varchar(255) NOT NULL DEFAULT 'none',
  `IP` varchar(24) NOT NULL,
  `money` varchar(10) NOT NULL DEFAULT '0',
  `admin` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `bb_customize` (
  `theme` varchar(11) NOT NULL DEFAULT 'BB_DEFAULT',
  `client_area` varchar(11) NOT NULL DEFAULT 'BB_DEFAULT'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `bb_customize` (`theme`) VALUES ('BB_DEFAULT');


-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `bb_announces`
--

CREATE TABLE `bb_announces` (
  `announce_id` int(11) NOT NULL,
  `announce_title` varchar(255) NOT NULL DEFAULT 'none',
  `announce` varchar(255) NOT NULL DEFAULT 'none',
  `announce_date` varchar(255) NOT NULL DEFAULT '0.0.0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `bb_settings`
--

CREATE TABLE `bb_settings` (
  `currency` varchar(255) NOT NULL,
  `currency_symbol` varchar(255) NOT NULL DEFAULT 'none'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO `bb_settings` (`currency`, `currency_symbol`) VALUES ('EUR', '€');
-- --------------------------------------------------------

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `bb_announces`
--

CREATE TABLE `bb_bans` (
  `banned_ip` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------


-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `bb_logs`
--

CREATE TABLE `bb_logs` (
  `id` int(11) NOT NULL,
  `date` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL DEFAULT 'none',
  `information` varchar(255) NOT NULL DEFAULT 'none'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `bb_invoices_no`
--

CREATE TABLE `bb_invoices_no` (
  `invoice_id` varchar(255) NOT NULL,
  `invoice_product_id` varchar(255) NOT NULL DEFAULT 'none',
  `invoice_buy` varchar(255) NOT NULL DEFAULT 'none',
  `invoice_owner` varchar(255) NOT NULL DEFAULT 'none',
  `invoice_total` varchar(255) NOT NULL DEFAULT '0.00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `bb_cart`
--

CREATE TABLE `bb_cart` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `owner` varchar(255) NOT NULL DEFAULT 'none',
  `appon` varchar(255) NOT NULL DEFAULT 'none',
  `price` varchar(255) NOT NULL DEFAULT 'none',
  `product_type` varchar(255) NOT NULL DEFAULT 'none',
  `domain` varchar(255) NOT NULL DEFAULT 'none'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `bb_comments`
--

CREATE TABLE `bb_comments` (
  `comment_id` int(11) NOT NULL,
  `comment_owner` varchar(255) NOT NULL DEFAULT 'none',
  `comment_message` varchar(255) NOT NULL DEFAULT 'none',
  `comment_ticket_id` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `bb_domains`
--

CREATE TABLE `bb_domains` (
  `id` int(11) NOT NULL,
  `domain_name` varchar(255) NOT NULL DEFAULT 'none',
  `domain_price` varchar(255) NOT NULL DEFAULT 'none',
  `domain_details` varchar(255) NOT NULL DEFAULT 'none'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `bb_invoices`
--

CREATE TABLE `bb_invoices` (
  `invoice_id` int(11) NOT NULL,
  `invoice_date` varchar(255) NOT NULL DEFAULT 'none',
  `invoice_owner` varchar(255) NOT NULL DEFAULT 'none',
  `invoice_no` varchar(255) NOT NULL DEFAULT 'none'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `bb_products`
--

CREATE TABLE `bb_products` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL DEFAULT 'none',
  `product_price` varchar(255) NOT NULL DEFAULT '0.0',
  `product_description` varchar(255) NOT NULL DEFAULT 'no description',
  `product_appon` varchar(255) NOT NULL DEFAULT 'none',
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `bb_product_category`
--

CREATE TABLE `bb_product_category` (
  `category_product_id` int(11) NOT NULL DEFAULT '0',
  `id` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL DEFAULT 'none'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `bb_services`
--

CREATE TABLE `bb_services` (
  `service_id` int(11) NOT NULL,
  `service_owner` varchar(255) NOT NULL DEFAULT 'none',
  `service_buy` varchar(255) NOT NULL DEFAULT 'none',
  `service_expire` varchar(255) NOT NULL DEFAULT 'none',
  `service_product_id` varchar(255) NOT NULL DEFAULT 'none',
  `service_category_id` varchar(255) NOT NULL DEFAULT 'none',
  `service_status` int(11) NOT NULL DEFAULT 0,
  `service_details` varchar(255) NOT NULL DEFAULT 'none'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `bb_services`
--

CREATE TABLE `bb_domains_owners` (
  `id` int(11) NOT NULL,
  `domain_name` varchar(255) NOT NULL DEFAULT 'none',
  `domain_owner` varchar(255) NOT NULL DEFAULT 'none',
  `domain_buy_date` varchar(255) NOT NULL DEFAULT 'none',
  `domain_expiry_date` varchar(255) NOT NULL DEFAULT 'none',
  `domain_details` varchar(255) NOT NULL DEFAULT 'none',
  `domain_status` int(11) NOT NULL DEFAULT 0,
  `domain_appon` varchar(255) NOT NULL DEFAULT 'none',
  `domain` varchar(255) NOT NULL DEFAULT 'none'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `bb_tickets`
--

CREATE TABLE `bb_tickets` (
  `id` int(11) NOT NULL,
  `ticket_name` varchar(255) NOT NULL DEFAULT 'none',
  `ticket_details` varchar(255) NOT NULL DEFAULT 'none',
  `ticket_status` int(11) NOT NULL DEFAULT 0,
  `ticket_owner` varchar(255) NOT NULL DEFAULT 'none',
  `ticket_date` varchar(255) NOT NULL DEFAULT '0.0.0.0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexuri pentru tabele eliminate
--

--
-- Indexuri pentru tabele `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`);

--

-- Indexuri pentru tabele `accounts`
--
ALTER TABLE `bb_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `bb_announces`
--
ALTER TABLE `bb_announces`
  ADD PRIMARY KEY (`announce_id`);

--
-- Indexuri pentru tabele `bb_cart`
--
ALTER TABLE `bb_cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `bb_comments`
--
ALTER TABLE `bb_comments`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexuri pentru tabele `bb_domains`
--
ALTER TABLE `bb_domains`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `bb_invoices`
--
ALTER TABLE `bb_invoices`
  ADD PRIMARY KEY (`invoice_id`);

--
-- Indexuri pentru tabele `bb_products`
--
ALTER TABLE `bb_products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexuri pentru tabele `bb_product_category`
--
ALTER TABLE `bb_product_category`
  ADD PRIMARY KEY (`category_product_id`);

--
-- Indexuri pentru tabele `bb_services`
--
ALTER TABLE `bb_services`
  ADD PRIMARY KEY (`service_id`);

--
-- Indexuri pentru tabele `bb_tickets`
--
ALTER TABLE `bb_tickets`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `bb_domains_owners`
  ADD PRIMARY KEY (`id`);


--
-- AUTO_INCREMENT pentru tabele eliminate
--

--
-- AUTO_INCREMENT pentru tabele `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `bb_domains_owners`
--
ALTER TABLE `bb_domains_owners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;


--
-- AUTO_INCREMENT pentru tabele `bb_logs`
--
ALTER TABLE `bb_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--

--
-- AUTO_INCREMENT pentru tabele `bb_announces`
--
ALTER TABLE `bb_announces`
  MODIFY `announce_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `bb_cart`
--
ALTER TABLE `bb_cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `bb_comments`
--
ALTER TABLE `bb_comments`
  MODIFY `comment_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `bb_domains`
--
ALTER TABLE `bb_domains`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `bb_invoices`
--
ALTER TABLE `bb_invoices`
  MODIFY `invoice_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `bb_products`
--
ALTER TABLE `bb_products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `bb_product_category`
--
ALTER TABLE `bb_product_category`
  MODIFY `category_product_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `bb_services`
--
ALTER TABLE `bb_services`
  MODIFY `service_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `bb_tickets`
--
ALTER TABLE `bb_tickets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
